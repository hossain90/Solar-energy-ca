import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Sun, Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'py-4 bg-white shadow-sm' : 'py-6 bg-transparent'
      }`}
    >
      <div className="container-narrow flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <Sun className="w-8 h-8" />
          <span className="text-xl font-light">SOLAR</span>
        </Link>

        {/* Desktop Menu */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link to="/" className="text-sm hover:opacity-70 transition-opacity">
            HOME
          </Link>
          <Link to="/calculator" className="text-sm hover:opacity-70 transition-opacity">
            CALCULATOR
          </Link>
          <Link to="/comparison" className="text-sm hover:opacity-70 transition-opacity">
            COMPARISON
          </Link>
          <Link to="/products" className="text-sm hover:opacity-70 transition-opacity">
            PRODUCTS
          </Link>
          <Link to="/about" className="text-sm hover:opacity-70 transition-opacity">
            ABOUT
          </Link>
        </nav>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? (
            <X className="w-6 h-6" />
          ) : (
            <Menu className="w-6 h-6" />
          )}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-md">
          <div className="container py-4 flex flex-col space-y-4">
            <Link 
              to="/" 
              className="px-4 py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              HOME
            </Link>
            <Link 
              to="/calculator" 
              className="px-4 py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              CALCULATOR
            </Link>
            <Link 
              to="/comparison" 
              className="px-4 py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              COMPARISON
            </Link>
            <Link 
              to="/products" 
              className="px-4 py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              PRODUCTS
            </Link>
            <Link 
              to="/about" 
              className="px-4 py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              ABOUT
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;