import React from 'react';

interface SolarPanelProps {
  className?: string;
}

const SolarPanel: React.FC<SolarPanelProps> = ({ className = '' }) => {
  return (
    <div className={`solar-panel-container ${className}`}>
      <div className="grid grid-cols-4 gap-1">
        {Array.from({ length: 20 }).map((_, index) => (
          <div
            key={index}
            className="aspect-square bg-blue-900 bg-opacity-90 relative overflow-hidden"
          >
            <div className="absolute inset-0.5 bg-gradient-to-br from-blue-800 to-blue-900">
              <div className="absolute inset-0 bg-grid-pattern opacity-30"></div>
            </div>
          </div>
        ))}
      </div>
      <div className="h-2 bg-gray-800 mt-1"></div>
    </div>
  );
};

export default SolarPanel;