export interface ProjectType {
  id: string;
  name: string;
  description: string;
  icon: string;
  baseLoad: number;
}

export interface SystemType {
  id: string;
  name: string;
  description: string;
  requiresBattery: boolean;
  efficiency: number;
}

export interface Material {
  id: string;
  name: string;
  description: string;
  category: string;
  specifications: Record<string, any>;
  prices: Record<string, number>;
}

export interface CalculatorInputs {
  projectType: string;
  systemType: string;
  location: string;
  consumption: number;
  batteryBackup: boolean;
  autonomyDays: number;
  panelEfficiency: number;
  currency: string;
}

export interface CalculatorResults {
  systemSize: number;
  numberOfPanels: number;
  dailyProduction: number;
  batterySize: number;
  materials: {
    panels: Material[];
    inverters: Material[];
    batteries: Material[];
    controllers: Material[];
    mounting: Material[];
    wiring: Material[];
    protection: Material[];
  };
  costs: {
    total: number;
    breakdown: Record<string, number>;
  };
  savings: {
    annual: number;
    paybackPeriod: number;
  };
}