import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Calculator from './pages/Calculator';
import Comparison from './pages/Comparison';
import Products from './pages/Products';
import About from './pages/About';
import Footer from './components/Footer';
import MouseTracker from './components/MouseTracker';

function App() {
  return (
    <Router>
      <div className="relative min-h-screen bg-white">
        <MouseTracker />
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/calculator" element={<Calculator />} />
            <Route path="/comparison" element={<Comparison />} />
            <Route path="/products" element={<Products />} />
            <Route path="/about" element={<About />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;