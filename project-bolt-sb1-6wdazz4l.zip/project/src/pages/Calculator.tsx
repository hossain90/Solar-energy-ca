import React, { useState } from 'react';
import { Sun, Home, Zap, DollarSign, ArrowRight, Battery, Calendar, Percent, Check, X } from 'lucide-react';
import EnergyAnimation from '../components/EnergyAnimation';
import { projectTypes, systemTypes, defaultPrices, currencySymbols } from '../data/calculator';
import { calculateSolarSystem } from '../utils/calculator';
import type { CalculatorInputs, CalculatorResults } from '../types/calculator';

const locations = [
  { name: 'New York', sunHours: 4.5 },
  { name: 'Los Angeles', sunHours: 5.5 },
  { name: 'Miami', sunHours: 5.8 },
  { name: 'Chicago', sunHours: 4.2 },
  { name: 'Houston', sunHours: 5.0 }
];

const Calculator: React.FC = () => {
  // Basic inputs
  const [location, setLocation] = useState<string>(locations[0].name);
  const [consumption, setConsumption] = useState<number>(30);
  const [selectedProjectType, setSelectedProjectType] = useState(projectTypes[0].id);
  const [selectedSystemType, setSelectedSystemType] = useState(systemTypes[0].id);
  
  // Professional mode inputs
  const [isProfessional, setIsProfessional] = useState(false);
  const [batteryBackup, setBatteryBackup] = useState(false);
  const [autonomyDays, setAutonomyDays] = useState(2);
  const [panelEfficiency, setPanelEfficiency] = useState(20);
  const [currency, setCurrency] = useState<string>('USD');
  
  // Results and UI state
  const [results, setResults] = useState<CalculatorResults | null>(null);
  const [showPlans, setShowPlans] = useState(false);

  const calculateSystem = () => {
    const inputs: CalculatorInputs = {
      projectType: selectedProjectType,
      systemType: selectedSystemType,
      location,
      consumption,
      batteryBackup,
      autonomyDays,
      panelEfficiency,
      currency,
      isProfessional
    };

    const calculationResults = calculateSolarSystem(inputs);
    setResults(calculationResults);
  };

  const handleGetQuote = () => {
    setShowPlans(true);
  };

  const handleSelectPlan = (plan: 'free' | 'pro' | 'enterprise') => {
    if (plan === 'free') {
      setIsProfessional(false);
      calculateSystem();
    } else {
      setIsProfessional(true);
      calculateSystem();
    }
    setShowPlans(false);
  };

  const selectedProject = projectTypes.find(type => type.id === selectedProjectType);
  const selectedSystem = systemTypes.find(type => type.id === selectedSystemType);

  return (
    <div className="pt-24 pb-16">
      <div className="container-narrow">
        <div className="text-center mb-16">
          <h1 className="mb-6">Solar Calculator</h1>
          <div className="separator mx-auto" />
          <p className="text-xl max-w-2xl mx-auto">
            Calculate your solar energy needs and potential savings with our {isProfessional ? 'professional' : 'free'} calculator.
          </p>
        </div>
        
        {showPlans ? (
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl text-center mb-12">Choose Your Plan</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Free Plan */}
              <div className="border border-gray-200 rounded-lg p-6 bg-white">
                <h3 className="text-2xl mb-2">Free</h3>
                <p className="text-gray-600 mb-4">Basic solar calculations</p>
                <p className="text-3xl mb-6">$0<span className="text-gray-500 text-lg">/month</span></p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-2" />
                    <span>Basic system size calculation</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-2" />
                    <span>Simple cost estimation</span>
                  </li>
                  <li className="flex items-center">
                    <X className="w-5 h-5 text-red-500 mr-2" />
                    <span className="text-gray-400">Detailed material breakdown</span>
                  </li>
                  <li className="flex items-center">
                    <X className="w-5 h-5 text-red-500 mr-2" />
                    <span className="text-gray-400">Professional report export</span>
                  </li>
                </ul>
                <button 
                  onClick={() => handleSelectPlan('free')}
                  className="w-full btn btn-outline"
                >
                  Select Free Plan
                </button>
              </div>

              {/* Pro Plan */}
              <div className="border-2 border-black rounded-lg p-6 bg-white relative">
                <div className="absolute top-0 right-0 bg-black text-white text-sm px-3 py-1 transform translate-y-[-50%]">
                  POPULAR
                </div>
                <h3 className="text-2xl mb-2">Professional</h3>
                <p className="text-gray-600 mb-4">Complete solar design suite</p>
                <p className="text-3xl mb-6">$49<span className="text-gray-500 text-lg">/month</span></p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-2" />
                    <span>All Free features</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-2" />
                    <span>Detailed material breakdown</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-2" />
                    <span>Professional PDF reports</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-2" />
                    <span>Advanced efficiency calculations</span>
                  </li>
                </ul>
                <button 
                  onClick={() => handleSelectPlan('pro')}
                  className="w-full btn btn-primary"
                >
                  Select Pro Plan
                </button>
              </div>

              {/* Enterprise Plan */}
              <div className="border border-gray-200 rounded-lg p-6 bg-white">
                <h3 className="text-2xl mb-2">Enterprise</h3>
                <p className="text-gray-600 mb-4">Custom solutions for businesses</p>
                <p className="text-3xl mb-6">Custom</p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-2" />
                    <span>All Pro features</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-2" />
                    <span>Custom API access</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-2" />
                    <span>Dedicated support</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-2" />
                    <span>Custom integrations</span>
                  </li>
                </ul>
                <button 
                  onClick={() => handleSelectPlan('enterprise')}
                  className="w-full btn btn-outline"
                >
                  Contact Sales
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Input Form */}
            <div className="bg-white border border-gray-200 rounded-lg p-8 shadow-lg">
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-2xl">Your Energy Profile</h2>
                <button
                  onClick={() => setIsProfessional(!isProfessional)}
                  className="text-sm underline hover:no-underline"
                >
                  Switch to {isProfessional ? 'Free' : 'Professional'} Mode
                </button>
              </div>
              
              <div className="space-y-8">
                {/* Project Type Selection */}
                <div>
                  <label className="text-lg mb-4 block">Project Type</label>
                  <div className="grid grid-cols-2 gap-4">
                    {projectTypes.map(type => (
                      <button
                        key={type.id}
                        onClick={() => setSelectedProjectType(type.id)}
                        className={`p-4 border rounded-lg text-left transition-colors ${
                          selectedProjectType === type.id
                            ? 'border-black bg-black text-white'
                            : 'border-gray-200 hover:border-black'
                        }`}
                      >
                        <h3 className="text-lg mb-1">{type.name}</h3>
                        <p className="text-sm opacity-80">{type.description}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* System Type Selection */}
                <div>
                  <label className="text-lg mb-4 block">System Type</label>
                  <div className="grid grid-cols-1 gap-4">
                    {systemTypes.map(type => (
                      <button
                        key={type.id}
                        onClick={() => {
                          setSelectedSystemType(type.id);
                          if (type.requiresBattery) {
                            setBatteryBackup(true);
                          }
                        }}
                        className={`p-4 border rounded-lg text-left transition-colors ${
                          selectedSystemType === type.id
                            ? 'border-black bg-black text-white'
                            : 'border-gray-200 hover:border-black'
                        }`}
                      >
                        <h3 className="text-lg mb-1">{type.name}</h3>
                        <p className="text-sm opacity-80">{type.description}</p>
                      </button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <label className="flex items-center text-lg mb-2">
                    <Home className="w-5 h-5 mr-2" />
                    <span>Location</span>
                  </label>
                  <select
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg"
                  >
                    {locations.map(loc => (
                      <option key={loc.name} value={loc.name}>
                        {loc.name} ({loc.sunHours} sun hours/day)
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="flex items-center text-lg">
                      <Zap className="w-5 h-5 mr-2" />
                      <span>Daily consumption</span>
                    </label>
                    <span className="font-medium">{consumption} kWh</span>
                  </div>
                  <input 
                    type="range" 
                    min="5" 
                    max="100" 
                    step="1"
                    value={consumption}
                    onChange={(e) => setConsumption(Number(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-full appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-sm text-gray-500 mt-1">
                    <span>5 kWh</span>
                    <span>100 kWh</span>
                  </div>
                </div>
                
                {isProfessional && (
                  <>
                    <div className="pt-4 border-t border-gray-200">
                      <h3 className="text-lg font-medium mb-4">Professional Options</h3>
                      
                      <div className="space-y-6">
                        {!selectedSystem?.requiresBattery && (
                          <div>
                            <label className="flex items-center text-lg mb-2">
                              <Battery className="w-5 h-5 mr-2" />
                              <span>Battery Backup</span>
                            </label>
                            <div className="flex gap-4">
                              <button
                                className={`flex-1 py-2 px-4 rounded-lg border ${
                                  batteryBackup
                                    ? 'bg-black text-white border-black'
                                    : 'border-gray-300 hover:border-black'
                                }`}
                                onClick={() => setBatteryBackup(true)}
                              >
                                Yes
                              </button>
                              <button
                                className={`flex-1 py-2 px-4 rounded-lg border ${
                                  !batteryBackup
                                    ? 'bg-black text-white border-black'
                                    : 'border-gray-300 hover:border-black'
                                }`}
                                onClick={() => setBatteryBackup(false)}
                              >
                                No
                              </button>
                            </div>
                          </div>
                        )}
                        
                        {(batteryBackup || selectedSystem?.requiresBattery) && (
                          <div>
                            <div className="flex justify-between items-center mb-2">
                              <label className="flex items-center text-lg">
                                <Calendar className="w-5 h-5 mr-2" />
                                <span>Autonomy Days</span>
                              </label>
                              <span className="font-medium">{autonomyDays} days</span>
                            </div>
                            <input 
                              type="range" 
                              min="1" 
                              max="7" 
                              step="1"
                              value={autonomyDays}
                              onChange={(e) => setAutonomyDays(Number(e.target.value))}
                              className="w-full h-2 bg-gray-200 rounded-full appearance-none cursor-pointer"
                            />
                            <div className="flex justify-between text-sm text-gray-500 mt-1">
                              <span>1 day</span>
                              <span>7 days</span>
                            </div>
                          </div>
                        )}
                        
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <label className="flex items-center text-lg">
                              <Percent className="w-5 h-5 mr-2" />
                              <span>Panel Efficiency</span>
                            </label>
                            <span className="font-medium">{panelEfficiency}%</span>
                          </div>
                          <input 
                            type="range" 
                            min="15" 
                            max="25" 
                            step="1"
                            value={panelEfficiency}
                            onChange={(e) => setPanelEfficiency(Number(e.target.value))}
                            className="w-full h-2 bg-gray-200 rounded-full appearance-none cursor-pointer"
                          />
                          <div className="flex justify-between text-sm text-gray-500 mt-1">
                            <span>15%</span>
                            <span>25%</span>
                          </div>
                        </div>

                        <div>
                          <label className="flex items-center text-lg mb-2">
                            <DollarSign className="w-5 h-5 mr-2" />
                            <span>Currency</span>
                          </label>
                          <select
                            value={currency}
                            onChange={(e) => setCurrency(e.target.value)}
                            className="w-full p-2 border border-gray-300 rounded-lg"
                          >
                            {Object.keys(currencySymbols).map(curr => (
                              <option key={curr} value={curr}>
                                {curr} ({currencySymbols[curr]})
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>
                  </>
                )}
                
                <button
                  onClick={calculateSystem}
                  className="btn btn-primary w-full flex items-center justify-center space-x-2"
                >
                  <span>Calculate System</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            {/* Results */}
            <div className="relative">
              <div className="absolute inset-0 overflow-hidden z-0 opacity-20 pointer-events-none">
                <EnergyAnimation />
              </div>
              
              <div className="relative z-10 bg-white border border-gray-200 rounded-lg p-8 shadow-lg">
                <h2 className="text-2xl mb-8">Your Solar Potential</h2>
                
                {results && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h3 className="text-lg font-medium mb-1">System Size</h3>
                        <p className="text-3xl font-light">{results.systemSize.toFixed(1)} kW</p>
                      </div>
                      
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h3 className="text-lg font-medium mb-1">Number of Panels</h3>
                        <p className="text-3xl font-light">{results.numberOfPanels}</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h3 className="text-lg font-medium mb-1">Daily Production</h3>
                        <p className="text-3xl font-light">{results.dailyProduction.toFixed(1)} kWh</p>
                      </div>
                      
                      {(batteryBackup || selectedSystem?.requiresBattery) && (
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <h3 className="text-lg font-medium mb-1">Battery Size</h3>
                          <p className="text-3xl font-light">{(results.batterySize / 1000).toFixed(1)} kWh</p>
                        </div>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 gap-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h3 className="text-lg font-medium mb-1">Estimated Cost</h3>
                        <p className="text-3xl font-light">
                          {currencySymbols[currency]}{results.costs.total.toLocaleString()}
                        </p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h3 className="text-lg font-medium mb-1">Annual Savings</h3>
                        <p className="text-3xl font-light">
                          {currencySymbols[currency]}{results.savings.annual.toLocaleString()}
                        </p>
                      </div>
                      
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h3 className="text-lg font-medium mb-1">Payback Period</h3>
                        <p className="text-3xl font-light">{results.savings.paybackPeriod.toFixed(1)} years</p>
                      </div>
                    </div>
                    
                    {isProfessional && (
                      <div className="border-t border-gray-200 pt-6 mt-6">
                        <h3 className="text-lg font-medium mb-4">Material Breakdown</h3>
                        <div className="space-y-4">
                          {Object.entries(results.costs.breakdown).map(([category, cost]) => (
                            <div key={category} className="flex justify-between items-center">
                              <span className="capitalize">{category}</span>
                              <span className="font-medium">
                                {currencySymbols[currency]}{cost.toLocaleString()}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <div className="mt-8">
                      <button 
                        onClick={handleGetQuote}
                        className="btn btn-primary w-full flex items-center justify-center space-x-2"
                      >
                        <span>Get a detailed quote</span>
                        <ArrowRight className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
        
        <div className="mt-16 text-center">
          <p className="text-gray-600 max-w-2xl mx-auto mb-4">
            This calculator provides estimates based on the information you provide. 
            Actual results may vary based on specific conditions at your location.
          </p>
          <p className="text-gray-600">
            For a more precise assessment, please contact our solar experts.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Calculator;