import { CalculatorInputs, CalculatorResults } from '../types/calculator';
import { defaultPrices, sunHours, efficiencyFactors, projectTypes, systemTypes } from '../data/calculator';

export const calculateSolarSystem = (inputs: CalculatorInputs): CalculatorResults => {
  const {
    projectType,
    systemType,
    location,
    consumption,
    batteryBackup,
    autonomyDays,
    panelEfficiency,
    currency
  } = inputs;

  // Get project and system type details
  const project = projectTypes.find(p => p.id === projectType);
  const system = systemTypes.find(s => s.id === systemType);
  
  if (!project || !system) {
    throw new Error('Invalid project or system type');
  }

  // Calculate system requirements
  const dailyConsumption = consumption * 1000; // Convert to Wh
  const locationSunHours = sunHours[location] || 4.5;
  const systemEfficiency = (panelEfficiency / 100) * system.efficiency;
  
  // Calculate required array size with efficiency factors
  let requiredArraySize = dailyConsumption / (locationSunHours * systemEfficiency);
  
  // Add safety margin for system type
  if (system.id === 'off-grid') {
    requiredArraySize *= 1.3; // 30% extra for off-grid systems
  } else if (system.id === 'hybrid') {
    requiredArraySize *= 1.15; // 15% extra for hybrid systems
  }

  // Standard panel wattage
  const standardPanelWattage = 400;
  
  // Calculate number of panels
  const numberOfPanels = Math.ceil(requiredArraySize / standardPanelWattage);
  
  // Calculate actual system size
  const systemSize = (numberOfPanels * standardPanelWattage) / 1000; // Convert to kW
  
  // Calculate daily production
  const dailyProduction = systemSize * locationSunHours * systemEfficiency;
  
  // Calculate battery size if needed
  const batterySize = (system.requiresBattery || batteryBackup)
    ? dailyConsumption * autonomyDays * 1.2 // Add 20% for depth of discharge
    : 0;

  // Calculate costs
  const prices = defaultPrices[currency];
  
  const panelCost = systemSize * 1000 * prices.panelPerWatt;
  const inverterCost = systemSize * 1000 * prices.inverterPerWatt;
  const batteryCost = batterySize ? (batterySize / 1000) * prices.batteryPerKwh : 0;
  const mountingCost = systemSize * 1000 * prices.mounting;
  const wiringCost = systemSize * 1000 * prices.wiring;
  const installationCost = prices.installation * Math.ceil(systemSize / 5); // Installation cost per 5kW
  const monitoringCost = prices.monitoring;
  const permitsCost = prices.permits;

  const costs = {
    total: Math.round(
      panelCost +
      inverterCost +
      batteryCost +
      mountingCost +
      wiringCost +
      installationCost +
      monitoringCost +
      permitsCost
    ),
    breakdown: {
      panels: Math.round(panelCost),
      inverter: Math.round(inverterCost),
      battery: Math.round(batteryCost),
      mounting: Math.round(mountingCost),
      wiring: Math.round(wiringCost),
      installation: Math.round(installationCost),
      monitoring: Math.round(monitoringCost),
      permits: Math.round(permitsCost)
    }
  };

  // Calculate savings
  const electricityRate = currency === 'USD' ? 0.15 : currency === 'EUR' ? 0.25 : 0.20;
  const annualProduction = dailyProduction * 365;
  const annualSavings = annualProduction * electricityRate;
  const paybackPeriod = costs.total / annualSavings;

  return {
    systemSize,
    numberOfPanels,
    dailyProduction,
    batterySize,
    materials: {
      panels: [],
      inverters: [],
      batteries: [],
      controllers: [],
      mounting: [],
      wiring: [],
      protection: []
    },
    costs,
    savings: {
      annual: Math.round(annualSavings),
      paybackPeriod
    }
  };
};

export const getLocationSunHours = (location: string): number => {
  return sunHours[location] || 4.5;
};

export const calculateEfficiencyLoss = (
  temperature: keyof typeof efficiencyFactors.temperature,
  shading: keyof typeof efficiencyFactors.shading,
  orientation: keyof typeof efficiencyFactors.orientation
): number => {
  return (
    efficiencyFactors.temperature[temperature] *
    efficiencyFactors.shading[shading] *
    efficiencyFactors.orientation[orientation]
  );
};